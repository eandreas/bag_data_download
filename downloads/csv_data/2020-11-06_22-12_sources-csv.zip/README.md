check schema/ for model information
check data/ for data
